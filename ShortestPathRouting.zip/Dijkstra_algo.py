from ryu.base import app_manager
from ryu.controller import ofp_event
from ryu.controller.handler import CONFIG_DISPATCHER, MAIN_DISPATCHER, set_ev_cls
from ryu.ofproto import ofproto_v1_3
from ryu.lib.packet import ethernet, ether_types, packet, ipv4, arp
from ryu.topology import event
from ryu.topology.api import get_switch, get_link, get_all_link
import networkx as nx
import sys
import logging

logger = logging.getLogger('myapp')
hdlr = logging.FileHandler('DEBUG.log')
formatter = logging.Formatter('%(asctime)s %(levelname)s %(message)s')
hdlr.setFormatter(formatter)
logger.addHandler(hdlr) 
logger.setLevel(logging.WARNING)

class packet_forwarding(app_manager.RyuApp):
    OFP_VERSIONS = [ofproto_v1_3.OFP_VERSION]
     
    global dijkstra, receive_arp, dpid_hostLookup

    def __init__(self, *args, **kwargs):
        super(packet_forwarding, self).__init__(*args, **kwargs)
        self.mac_to_port = {}
        self.g = nx.DiGraph()
        self.topo = {}

    def dijkstra(graph,src,dest,visited=[],distances={},predecessors={}):
        if src not in graph:
            raise TypeError('The root of the shortest path tree cannot be found')
        if dest not in graph:
            raise TypeError('The target of the shortest path cannot be found')

        path = []
        if src == dest:
            # We build the shortest path and display it
            pred=dest
            while pred != None:
                path.append(pred)
                pred=predecessors.get(pred,None)
            #  return (str(path))
            print('shortest path: '+str(path))
        else :
            if not visited:
                distances[src]=0
            # visit the neighbors
            for neighbor in graph[src] :
                if neighbor not in visited:
                    new_distance = distances[src] + graph[src][neighbor]
                    if new_distance > distances.get(neighbor,float('0')):
                        distances[neighbor] = new_distance
                        predecessors[neighbor] = src
            # mark as visited
            visited.append(src)
            unvisited={}
            for k in graph:
                if k not in visited:
                    unvisited[k] = distances.get(k,float('0'))
            x=max(unvisited, key=unvisited.get) # Change to min for longest path / pkt transmission time
            dijkstra(graph,x,dest,visited,distances,predecessors)

    @set_ev_cls(ofp_event.EventOFPSwitchFeatures, CONFIG_DISPATCHER)
    def switch_features_handler(self,ev):
        datapath= ev.msg.datapath
        ofproto = datapath.ofproto
        parser = datapath.ofproto_parser
        match = parser.OFPMatch()
        actions = [parser.OFPActionOutput(ofproto.OFPP_CONTROLLER,ofproto.OFPCML_NO_BUFFER)]
        self.add_flow(datapath, 0, match, actions)

#### Using RYU topology module to create a network graph

    def add_flow(self, datapath, priority, match, actions, buffer_id=None):
        parser = datapath.ofproto_parser
        ofproto = datapath.ofproto
        inst = [parser.OFPInstructionActions(ofproto.OFPIT_APPLY_ACTIONS, actions)]
        if buffer_id:
            mod = parser.OFPFlowMod(datapath=datapath, priority=priority, match=match, buffer_id=buffer_id, instructions=inst)
        else:
            mod = parser.OFPFlowMod(datapath=datapath, priority=priority, match=match, instructions=inst)
            datapath.send_msg(mod)

    def delete_flow(self, datapath):
        ofproto = datapath.ofproto
        parser = datapath.ofproto_parser

        for dst in self.mac_to_port[datapath.id].keys():
            match = parser.OFPMatch(eth_dst=dst)
            mod = parser.OFPFlowMod(
                datapath, command=ofproto.OFPFC_DELETE,
                out_port=ofproto.OFPP_ANY, out_group=ofproto.OFPG_ANY,
                priority=1, match=match)
            datapath.send_msg(mod)

    def dpid_hostLookup(self,lmac):
        
        #host_locate = {1:'00:00:00:00:00:01', 2:'00:00:00:00:00:02', 3:'00:00:00:00:00:03',4:'00:00:00:00:00:04', 5:'00:00:00:00:00:0        5        ',6:'00:00:00:00:00:06', 7:'00:00:00:00:00:08'}
        host_locate = {4:{'00:00:00:00:00:04','00:00:00:00:00:05'}, 5:{'00:00:00:00:00:06','00:00:00:00:00:07'}, 6:{'00:00:00:00:00:08','00:00:00:00:00:09'}, 7:{'00:00:00:00:00:A','00:00:00:00:00:B'}, 8:{'00:00:00:00:00:C','00:00:00:00:00:D'}, 9:{'00:00:00:00:00:E','00:00:00:00:00:F'}, 1:'00:00:00:00:00:01', 2:'00:00:00:00:00:02', 3:'00:00:00:00:00:03'}
        for dpid,mac in host_locate.iteritems():
            if lmac in mac:
                return dpid

    def retrieve_port(self,Mac_to_port,dpid,mac):
        return Mac_to_port[dpid][mac]

##### PacketIn handler (Switch ---> Controller)

    @set_ev_cls(ofp_event.EventOFPPacketIn, MAIN_DISPATCHER)
    def _packet_in_handler(self, ev):

        sys.stdout.write("We are in _packet_in_handler()")
        msg = ev.msg
        datapath = msg.datapath
        ofproto = datapath.ofproto
        parser = datapath.ofproto_parser
        in_port = msg.match['in_port']
        pkt = packet.Packet(msg.data)
        eth = pkt.get_protocols(ethernet.ethernet)[0]        
       
        if eth.ethertype == ether_types.ETH_TYPE_LLDP:
            return

        dst = eth.dst
        src = eth.src
        dpid = datapath.id
        self.mac_to_port.setdefault(dpid, {})
        self.mac_to_port[dpid][src] = in_port
   
        topo = {}
        switch_list = get_switch(self, None)
        switches = [switch.dp.id for switch in switch_list]
        links_list = get_link(self, None)

        # Links and Associated Bandwidth 
        link_bw = {(1,5):15,(1,7):15,(2,5):10,(2,6):5,(2,7):20, (2,9):10,(3,7):5,(3,8):10,(3,10):15,(4,8):15,(4,10):15,(5,11):1,(5,12):1,(6,11):1,(6,12):1,(7,13):1,(7,14):1,(8,13):1,(8,14):1,(9,15):1,(9,16):1,(10,15):1,(10,16):1}
        # Links and associated ports linking them
        link_port = {(link.src.dpid, link.dst.dpid):link.src.port_no for link in links_list}  # store link information with src port n
        # Only stores links (1,2) meaning they are directly connected
        links = [(link.src.dpid, link.dst.dpid) for link in links_list] # store link information only
        
        sys.stdout.write(dst)
        logger.info('Destination :',dst,'Source:',src)
        dst_dpid = dpid_hostLookup(self,dst)
        logger.info("About to Start Dijkstra ...!!")
        
        # Build network graph with collect link information
        g = nx.DiGraph()
        g.add_edges_from(links)
        g.add_nodes_from(switches)
        
        for i in switches:
            bw = {}
            next_hops = list(g.neighbors(i))
            for j in next_hops:
                lbw = {str(j):link_bw[i,j]}
                bw.update(lbw)
            subtopo = {str(i):bw}
            topo.update(subtopo)

        # Look for dest host dpid
        # Find the shortest path between the origin dpid and the dest dpid
        path = dijkstra(topo,str(dpid),str(dst_dpid))
       
        # Your path output will be link [4,2,1] as the path between 1--->4
        # From link_port list, you can retrieve the port of the link between (1,2), (2,4) on the path 
        # With port number, dpid and dst as mac, install Flow rule to switch
        

#####  install flow
        if output_port != ofproto.OFPP_FLOOD:
            match = parser.OFPMatch(in_port=in_port, eth_src=src, eth_dst=dst)
            if msg.buffer_id != ofproto.OFP_NO_BUFFER:
                self.add_flow(datapath, 1, match, actions, msg.buffer_id)
                return
            else:
              match = parser.OFPMatch(in_port=in_port, eth_src=src, eth_dst=dst)
              self.add_flow(datapath, 1, match, actions)
        data = None

        if msg.buffer_id == ofproto.OFP_NO_BUFFER:
             data = msg.data
        out = parser.OFPPacketOut(datapath=datapath, buffer_id = msg.buffer_id, in_port = in_port, actions = actions, data=data)
        datapath.send_msg(out)

