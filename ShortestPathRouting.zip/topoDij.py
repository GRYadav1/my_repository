#!/usr/bin/python

from mininet.topo import Topo
from mininet.net import Mininet
from mininet.util import irange,dumpNodeConnections
from mininet.link import TCLink
from mininet.node import CPULimitedHost
from mininet.log import setLogLevel
from mininet.node import RemoteController
from mininet.cli import CLI

class LinearTopo(Topo):
   "Tree topology with fanout 2"

   def __init__(self, **opts):
       """Init.
       """
       super(LinearTopo, self).__init__(**opts)

       h1=self.addHost('h1',ip="10.1.0.1",mac="00:00:00:00:00:01");
       h2=self.addHost('h2',ip="10.1.0.2",mac="00:00:00:00:00:02");
       h3=self.addHost('h3',ip="10.1.0.3",mac="00:00:00:00:00:03");
       sr1=self.addHost('sr1',ip="10.0.0.1",mac="00:00:00:00:00:04");
       sr2=self.addHost('sr2',ip="10.0.0.2/8",mac="00:00:00:00:00:05");
       sr3=self.addHost('sr3',ip="10.0.0.3/8",mac="00:00:00:00:00:06");
       sr4=self.addHost('sr4',ip="10.0.0.4/8",mac="00:00:00:00:00:07");
       sr5=self.addHost('sr5',ip="10.0.1.1/8",mac="00:00:00:00:00:08");
       sr6=self.addHost('sr6',ip="10.0.1.2/8",mac="00:00:00:00:00:09");
       sr7=self.addHost('sr7',ip="10.0.1.3/8",mac="00:00:00:00:00:A");
       sr8=self.addHost('sr8',ip="10.0.1.4/8",mac="00:00:00:00:00:B");
       sr9=self.addHost('sr9',ip="10.0.2.1/8",mac="00:00:00:00:00:C");
       sr10=self.addHost('sr10',ip="10.0.2.2/8",mac="00:00:00:00:00:D");
       sr11=self.addHost('sr11',ip="10.0.2.3/8",mac="00:00:00:00:00:E");
       sr12=self.addHost('sr12',ip="10.0.2.4/8",mac="00:00:00:00:00:F");

       s1=self.addSwitch('s1');
       s2=self.addSwitch('s2');
       s3=self.addSwitch('s3');
       s4=self.addSwitch('s4');
       s5=self.addSwitch('s5');
       s6=self.addSwitch('s6');
       s7=self.addSwitch('s7');
       s8=self.addSwitch('s8');
       s9=self.addSwitch('s9');
       s10=self.addSwitch('s10');
       s11=self.addSwitch('s11');
       s12=self.addSwitch('s12');
       s13=self.addSwitch('s13');
       s14=self.addSwitch('s14');
       s15=self.addSwitch('s15');
       s16=self.addSwitch('s16');


       self.addLink(s1,s5);
       self.addLink(s1,s7);
       self.addLink(s2,s5);
       self.addLink(s2,s6);
       self.addLink(s2,s7);
       self.addLink(s2,s9);
       self.addLink(s3,s7);
       self.addLink(s3,s8);
       self.addLink(s3,s10);
       self.addLink(s4,s8);
       self.addLink(s4,s10);
       self.addLink(s5,s11);
       self.addLink(s5,s12);
       self.addLink(s6,s11);
       self.addLink(s6,s12);
       self.addLink(s7,s13);
       self.addLink(s7,s14);
       self.addLink(s8,s13);
       self.addLink(s8,s14);
       self.addLink(s9,s15);
       self.addLink(s9,s16);
       self.addLink(s10,s15);
       self.addLink(s10,s16);


       self.addLink(s11,sr1);
       self.addLink(s11,sr2);
       self.addLink(s12,sr3);
       self.addLink(s12,sr4);
       self.addLink(s13,sr5);
       self.addLink(s13,sr6);
       self.addLink(s14,sr7);
       self.addLink(s14,sr8);
       self.addLink(s15,sr9);
       self.addLink(s15,sr10);
       self.addLink(s16,sr11);
       self.addLink(s16,sr12);

       self.addLink(h1,s1);
       self.addLink(h2,s2);
       self.addLink(h3,s4);


def simpleTest():
    "Create and test a simple network"
    topo = LinearTopo()
    net = Mininet(topo, controller= None, autoStaticArp = True)

    #Add a Controller
    net.addController("C_0", controller=RemoteController,
                      ip='127.0.0.1',
                      port=6653)
    net.start()
    print "Dumping host connections"
    dumpNodeConnections(net.hosts)
    print "Testing network connectivity"
    net.pingAll()
    CLI(net)
    net.stop()


if __name__ == '__main__':
 # Tell mininet to print useful information
    setLogLevel('info')
    simpleTest()
topos = { 'mytopo': ( lambda: LinearTopo())  }
